#include <stdio.h>
#include <string.h>


int main(){
    //variaveis usadas
    float peso = -1;
    float altura = -1;
    int idade = -1;
    char sexo ='\0';
    float IMC;

    printf("\n=== CALCULADORA DE IMC AVANCADA ===\n");
    

    // loops while que prendem o usuario caso ele digite algo errado
    while (peso <=0)
    {
        printf("\nDigite seu peso (quilos): ");
        scanf("%f", &peso);

        if (peso <=0){
            printf("\nDigite um peso valido");
        }
    }
    
    while (altura <=0) 
    {
        printf("\nDigite sua altura (metros): ");
        scanf("%f", &altura);

        if (altura <=0 || altura >3){
            printf("\nDigite uma altura valida em metros");
        }
    }
    
    while (idade <=0)
    {
        printf("\nDigite sua idade: ");
        scanf("%d", &idade);

        if (idade <=0){
            printf("\nDigite uma idade valida");
        }
    }    

    while (sexo !='f' && sexo !='m' && sexo !='F' && sexo !='M') 
    {
        printf("\nDigite seu sexo (F para Feminino e M para Masculino): ");
        scanf(" %c", &sexo);
        if (sexo !='f' && sexo !='m' && sexo !='F' && sexo !='M'){
            printf("\nDigite um sexo valido");
        }

    }

    IMC = peso/(altura*altura); //calculo do IMC
    //condicionais para cada caso
    if (IMC < 18.5){
        //abaixo_peso
        printf("\nSeu IMC = %.2f, portanto voce esta abaixo do peso.\n", IMC);

        if (idade >=60){
            printf("\nRecomendacao Personalizada: consultar geriatra");
        }
    }

    if (18.5 <= IMC && IMC < 25){
        //peso_normal
        printf("\nSeu IMC = %.2f, portanto voce tem peso normal.\n", IMC);
    }

    if (25 <= IMC && IMC < 30){
        //sobrepeso
        printf("\nSeu IMC = %.2f, portanto voce tem sobrepeso.\n", IMC);

        if (sexo =='m' || sexo =='M'){
            printf("\nRecomendacao Personalizada: exercicios de forca");
        } else{
            printf("\nRecomendacao Personalizada: exercicios aerobicos");
        }

    }

    if (30 <= IMC && IMC <35){
        //obesidade1
        printf("\nSeu IMC = %.2f, portanto voce tem obesidade grau I\n", IMC);

        if (sexo =='m' || sexo =='M'){
            printf("\nRecomendacao Personalizada: exercicios de forca");
        } else{
            printf("\nRecomendacao Personalizada: exercicios aerobicos");
        }

        if (idade <=25){
            printf("\nRecomendacao Personalizada: procurar nutricionista");
        }
    }

    if (35 <= IMC && IMC <40){
        //obesidade2
        printf("\nSeu IMC = %.2f, portanto voce tem obesidade grau II\n", IMC);

        if (sexo =='m' || sexo =='M'){
            printf("\nRecomendacao Personalizada: exercicios de forca");
        } else{
            printf("\nRecomendacao Personalizada: exercicios aerobicos");
        }
        if (idade <=25){
            printf("\nRecomendacao Personalizada: procurar nutricionista");
        }
    }

    if (IMC >=40){
        //obesidade3
        printf("\nSeu IMC = %.2f, portanto voce tem obesidade grau III\n", IMC);

        if (sexo =='m' || sexo =='M'){
            printf("\nRecomendacao Personalizada: exercicios de forca");
        } else{
            printf("\nRecomendacao Personalizada: exercicios aerobicos");
        }

        if (idade <=25){
            printf("\nRecomendacao Personalizada: procurar nutricionista");
        }
    }

    return 0;
}
