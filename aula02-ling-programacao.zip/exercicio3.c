#include <stdio.h>

float saldo = 1000; //saldo inicial 1000

//funcoes usadas no codigo:

void consultar_saldo(){
    printf("\nSaldo atual:R$ %.2f\n", saldo);

}

void deposito(){
    float valor_depositado = 0; 
    char resposta_s_n = '\0';
    printf("\nDigite a quantia que sera depositada na conta: ");
    scanf("%f", &valor_depositado);

    if (valor_depositado > 0.01){ //valor minimo R$0,01
        saldo += valor_depositado;

        while (resposta_s_n !='s' && resposta_s_n !='n' && resposta_s_n !='S' && resposta_s_n !='N'){ 
            printf("\nTem certeza que deseja depositar R$%.2f na conta?(s/n)", valor_depositado); //pergunta sim ou não
            scanf(" %c", &resposta_s_n);
            if (resposta_s_n == 's' || resposta_s_n == 'S'){ //resposta sim
                printf("\nDeposito executado!");
                printf("\nSaldo atual:R$ %.2f\n", saldo);
            }
            if (resposta_s_n == 'n' || resposta_s_n == 'N'){ //resposta não
                printf("Deposito cancelado\n");
                printf("\nSaldo atual: R$ %.2f\n", saldo);
            }
            if (resposta_s_n != 's' && resposta_s_n!= 'n' && resposta_s_n != 'S' && resposta_s_n != 'N'){ //resposta diferente de s ou n
                printf("Digite como resposta apenas s (para sim) ou n (para nao)");
            }
        }
    } else {
        printf("\nO valor a ser depositado na conta precisa ser maior que o minimo de R$0,01\n");
    }
}

void saque(){
    float valor_sacado = 0;
    char resposta_s_n = '\0';
    printf("\nDigite a quantia que sera sacada (maximo de R$500,00 por operacao): ");
    scanf("%f", &valor_sacado);

    if (valor_sacado > 0 && valor_sacado <= saldo && valor_sacado <=500){
        while (resposta_s_n !='s' && resposta_s_n !='n' && resposta_s_n !='S' && resposta_s_n !='N'){
            printf("\nTem certeza que deseja sacar R$%.2f?(s/n)", valor_sacado); //pergunta sim ou não
            scanf(" %c", &resposta_s_n);
            if (resposta_s_n == 's' || resposta_s_n == 'S'){ //resposta sim
                saldo -= valor_sacado;
                printf("\nSaque realizado!");
                printf("\nSaldo atual: R$ %.2f\n", saldo);
            }
            if (resposta_s_n == 'n' || resposta_s_n == 'N'){ //resposta não
                printf("\nSaque cancelado");
                printf("\nSaldo atual: R$ %.2f\n", saldo);
            }
            if (resposta_s_n !='s' && resposta_s_n !='n' && resposta_s_n != 'S' && resposta_s_n != 'N'){ //resposta diferente de s ou n
                printf("Digite como resposta apenas s (para sim) ou n (para nao)");
            }
        }   
    } else{
        printf("\nValor invalido para saque!");
        printf("\nO Saque deve ser compativel com o seu saldo atual e tem o limite de R$500,00 por operacao");
        printf("\nSaldo atual: R$ %.2f\n", saldo);
    }


}

void transferencia(){
    int numero_conta = 0;
    float valor_transferido;
    char reposta_s_n ='\0';

    printf("\nDigite o numero da conta para a qual sera realizada a transferencia: ");
    scanf("%d", &numero_conta);
    printf("\nDigite o valor que sera transferido: ");
    scanf("%f", &valor_transferido);

    while (reposta_s_n !='s' && reposta_s_n !='n' && reposta_s_n !='S' && reposta_s_n !='N')
    { 
        printf("Tem certeza que quer transferir R$%.2f para a conta de numero %d com taxa de 1/100 (minimo de R$2,00)? (s/n)", valor_transferido, numero_conta); //pergunta de sim ou não
        scanf(" %c", &reposta_s_n);
        if (reposta_s_n !='s' && reposta_s_n !='n' && reposta_s_n !='S' && reposta_s_n !='N'){ //resposta diferente de s ou n 
            printf("Digite como resposta apenas s (para sim) ou n (para nao)");
        }
    }
    
    if (reposta_s_n == 's' || reposta_s_n == 'S'){ //resposta sim
            if (valor_transferido <= saldo && valor_transferido > 0){
                saldo -= valor_transferido;
                    //taxa de transferencia (minima de 2)s
                    if (valor_transferido >= 200){
                        saldo -= valor_transferido/100;
                    } else{
                        saldo -= 2;
                    }
                printf("\nTransferencia realizada!");
                printf("\nSaldo atual: R$ %.2f\n", saldo);
            } else{
                printf("\nA transferencia deve ser compativel com o seu saldo atual");
                printf("\nSaldo atual: R$ %.2f\n", saldo);
            }
    }
    if (reposta_s_n == 'n' || reposta_s_n == 'N'){ //resposta não
        printf("\nTransferencia cancelada");
        printf("\nSaldo atual: R$ %.2f\n", saldo);
    }


}

// ----------------- fim das funcoes ---------------

int main(){
    //corpo
    int resposta = -1;
    while (resposta!=5){
        printf("\n===SIMULADOR DE CAIXA ELETRONICO===");
        printf("\nVoce pode fazer as seguintes operacoes digitando os numeros:");
        printf("\n1 - Consultar saldo atual");
        printf("\n2 - Realizar deposito");
        printf("\n3 - Realizar saque");
        printf("\n4 - Transferencia para conta");
        printf("\n5 - Sair do sistema");
        printf("\n--> ");

        scanf("%d", &resposta);

        if (resposta == 1){
            consultar_saldo();
        }
        if (resposta == 2){
            deposito();
        }
        if (resposta == 3){
            saque();
        }
        if (resposta == 4){
            transferencia();
        }

    }


    return 0;
}