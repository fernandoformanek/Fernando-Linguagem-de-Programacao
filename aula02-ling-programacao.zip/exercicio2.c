#include <stdio.h>

int main(){
    float nota1 = -1;
    float nota2 = -1;
    float nota3 = -1;

    float frequencia = -1;
    
    printf("\n===SISTEMA DE CALCULO DE NOTAS E CONCEITOS==="); //titulo
    printf("\n--> APENAS nota de 0 a 10 <---");
    while (nota1 < 0 || nota1 >10) //loop while para garantir que a nota digitada seja entre 0 e 10
    {
    printf("\nDigite a nota 1: ");
    scanf("%f", &nota1);
    }

    while (nota2 < 0 || nota2 >10)
    {    
    printf("\nDigite a nota 2: ");
    scanf("%f", &nota2);
    }
    
    while (nota3 < 0 || nota3 >10)
    {    
    printf("\nDigite a nota 3: ");
    scanf("%f", &nota3);
    }

    while (frequencia < 0 || frequencia >100)
    {
    printf("\nDigite a frequencia do aluno --> (0 a 100) <--: "); //loop while para garantir a frequencia digitada entre 0 e 100
    scanf("%f", &frequencia);
    }
    
    float media_nota = (nota1 + nota2 + nota3)/3;
    
    printf("\nMedia das notas: %.2f", media_nota);
    printf("\nFrequencia: %.2f", frequencia);

    if (media_nota >= 5 && frequencia >=75){ //ifs para verificar a aprovacao em todos os casos
            
        printf("\nAprovado por nota e por frequencia");

        if (media_nota >= 9){
            printf("\nConceito A obtido");
        }
        if (media_nota >=7 && media_nota <9){
            printf("\nConceito B obtido");
        } 
        if (media_nota <7){
            printf("\nConceito C obtido");
        }
    }

    if (media_nota >= 5 && frequencia <75){
            
        printf("\nAprovado por nota, POREM, reprovado por frequencia");

        if (media_nota >= 9){
            printf("\nConceito A obtido");
        }
        if (media_nota >=7 && media_nota <9){
            printf("\nConceito B obtido");
        } 
        if (media_nota <7){
            printf("\nConceito C obtido");
        }
        

    }
    if (media_nota <5 && frequencia >=75){

        printf("\nReprovado por nota");
        printf("\nConceito D obtido");
    }

    if (media_nota <5 && frequencia <75){
        
        printf("\nReprovado por nota e por frequencia");
        printf("\nConceito D obtido");

    }

    return 0;
}