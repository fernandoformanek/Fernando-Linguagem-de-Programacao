#include <stdio.h>

int main(){

    int pontuacao_inicial;
    int resposta = -1;
    
    printf("\n===Sistema de Pontuacao de Jogo==="); //titulo
    printf("\nInsira a pontuacao inicial do jogador: ");
    scanf("%d", &pontuacao_inicial); //pega a pontuacao inicial do usuario

    if (pontuacao_inicial<0){  //garante que a pontuacao inicial digitada é maior ou igual a 0
        printf("Impossivel comecar com pontos negativos");
    } else{

        while (resposta!=6) //se a resposta for 6 o programa encerra
        {
            printf("\n\nDigite os seguintes valores para os eventos:");
            printf("\n1 - Ganhou uma fase");
            printf("\n2 - Coletou item especial");
            printf("\n3 - Perdeu uma vida");
            printf("\n4 - Bonus de tempo");
            printf("\n5 - Penalidade por dificuldade");
            printf("\n6 - Encerrar");
            printf("\n--> ");

            scanf("%d", &resposta); //pega a resposta digitada pelo usuario
            //para cada possivel evento:
            if (resposta == 1){
                pontuacao_inicial += 50;
                printf("\n\nGanhou uma fase! pontuacao atual: %d pontos", pontuacao_inicial);     
            }
            if (resposta == 2){
                pontuacao_inicial *= 2;
                printf("\n\nColetou um item especial! pontuacao atual: %d pontos", pontuacao_inicial);     
            }
            if (resposta == 3){
                pontuacao_inicial -= 30;
                printf("\n\nPerdeu uma vida! pontuacao atual: %d pontos", pontuacao_inicial);     
            }
            if (resposta == 4){
                pontuacao_inicial += 15;
                printf("\n\nBonus de tempo! pontuacao atual: %d pontos", pontuacao_inicial);     
            }
            if (resposta == 5){
                pontuacao_inicial /= 3;
                printf("\n\nPenalidade por dificuldade! pontuacao atual: %d pontos", pontuacao_inicial);     
            }
            if (resposta<1 || resposta>6){
                printf("\n\nValor digitado invalido");
            }
            
        }
        
        printf("\n\n===Final de jogo==="); 
        printf("\nPontuacao final: %d pontos", pontuacao_inicial); }
    return 0;
}