#include <stdio.h>

#include <string.h>


// Função para inverter uma string usando ponteiros

void inverter_string(char *str) {

// TODO: Implemente usando dois ponteiros

// Um no início e outro no fim da string

    char *inicio = str; //ponteiro no incio da string
    char *fim = str + strlen(str) -1; //ponteiro no final da string

    while (inicio < fim)
    {
        char i = *inicio;
        *inicio = *fim;
        *fim = i;
        inicio++;
        fim--;
    }
    
}


int main() {

char texto[] = "PONTEIROS";


printf("String original: %s\n", texto);

inverter_string(texto);

printf("String invertida: %s\n", texto);


return 0;

}