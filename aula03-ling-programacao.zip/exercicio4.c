#include <stdio.h>

int main(){
    //declaracao da matriz 3x3
    float matriz[3][3]={
    };

    float soma_diagonal_principal;


    //loop para armazenar todos os elementos da matriz
    for (int i=0;i<3;i++){ //percorre uma vez para cada linha
        for (int j=0;j<3;j++){  //percorre uma vez para cada coluna
            printf("\nDigite o elemento %dx%d da matriz: ",i+1,j+1);
            scanf("%f", &matriz[i][j]);
        }
    }

    //exibe a matriz na tela
    for (int i=0;i<3;i++){
        for (int j=0;j<3;j++){
            printf("%.2f\t", matriz[i][j]);

        }
        printf("\n");
    }

    //calcula a soma dos elementos da diagonal principal
    soma_diagonal_principal = matriz[0][0] + matriz[1][1] + matriz[2][2];
    printf("\nA soma dos elementos da diagonal principal eh: %.2f", soma_diagonal_principal);




}