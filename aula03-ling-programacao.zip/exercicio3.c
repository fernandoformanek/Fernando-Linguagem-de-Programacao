#include <stdio.h>

int main(){
    //declaracao da matriz 2x2
    float matriz[2][2]={
    };
    //variavel maior elemento
    float maior_elemento;

    //loop para armazenar todos os elementos da matriz

    for (int i=0;i<2;i++){ //percorre uma vez para cada linha
        for (int j=0;j<2;j++){  //percorre uma vez para cada coluna
            printf("\nDigite o elemento %dx%d da matriz: ",i+1,j+1);
            scanf("%f", &matriz[i][j]);
        }
    }

    //exibe a matriz na tela
    for (int i=0;i<2;i++){
        for (int j=0;j<2;j++){
            printf("%.2f\t", matriz[i][j]);

        }
        printf("\n");
    }

    //compara cada numero e determina qual é o maior
    for (int i=0;i<2;i++){
        for (int j=0;j<2;j++){
            if (matriz[i][j] > maior_elemento){
                maior_elemento = matriz[i][j];
            }

        }
    }    
    
    printf("\nO maior elemento da matriz eh: %.2f", maior_elemento);
    

}