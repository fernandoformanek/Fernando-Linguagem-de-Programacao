#include <stdio.h>

int main(){
    //declaracao do vetor
    float numeros[5];

    //loop for para armazenar todos os itens do vetor digitados pelo usuario
    for (int i = 0; i<5; i++){
        printf("Digite o numero %d: ", i+1);
        scanf("%f", &numeros[i]);
    }

    //loop for para percorrer os numeros e verificar se são > que 10
    printf("\nMostrando apenas numeros maiores que 10:");
    for (int i = 0; i<5; i++){
        if (numeros[i] > 10){
            printf("\n%.2f", numeros[i]);

        } 
    }
}