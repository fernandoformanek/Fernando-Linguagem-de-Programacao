#include <stdio.h>

int main(){
    //variaveis
    float numeros[4];
    float soma;
    float media;

    //pega os 4 numeros do usuario
    printf("\nDigite o primeiro numero: ");
    scanf("%f", &numeros[0]);

    printf("Digite o segundo numero: ");
    scanf("%f", &numeros[1]);    

    printf("Digite o terceiro numero: ");
    scanf("%f", &numeros[2]);

    printf("Digite o quarto numero: ");
    scanf("%f", &numeros[3]);

    //loop for para somar os numeros 
    for (int i = 0; i<4; i++){
        soma += numeros[i];
    }
    //calculo da media
    media = soma /4;

    printf("\nA media dos numeros eh: %.2f", media);
}