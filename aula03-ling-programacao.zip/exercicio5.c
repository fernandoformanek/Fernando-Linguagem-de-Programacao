#include <stdio.h>

int main(){
    //declaracao da matriz 2x3
    float matriz[2][3]={
    };

    float soma_diagonal_principal;

    int contagem_maiores_5=0;

    //loop para armazenar todos os elementos da matriz
    for (int i=0;i<2;i++){ //percorre uma vez para cada linha
        for (int j=0;j<3;j++){  //percorre uma vez para cada coluna
            printf("\nDigite o elemento %dx%d da matriz: ",i+1,j+1);
            scanf("%f", &matriz[i][j]);
        }
    }

    //exibe a matriz na tela
    for (int i=0;i<2;i++){
        for (int j=0;j<3;j++){
            printf("%.2f\t", matriz[i][j]);

        }
        printf("\n");
    }

    //loop para verificar quais elementos sao maiores que 5
    for (int i=0;i<2;i++){
        for (int j=0;j<3;j++){
            if (matriz[i][j] > 5){
                contagem_maiores_5 += 1;
            }

        }
        printf("\n"); 
    }
    printf("\n%d elementos da matriz sao maiores que 5", contagem_maiores_5);
}